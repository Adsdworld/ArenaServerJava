var interfacecom_1_1arena_1_1game_1_1entity_1_1_i_living_entity =
[
    [ "die", "interfacecom_1_1arena_1_1game_1_1entity_1_1_i_living_entity.html#a6fae3beb405911ec8631eaf53bc2b5d4", null ]
];