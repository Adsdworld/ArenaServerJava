var classcom_1_1arena_1_1game_1_1handler_1_1_cast_r_handler =
[
    [ "handle", "classcom_1_1arena_1_1game_1_1handler_1_1_cast_r_handler.html#a51d17ddee2b0efe64f19568326aea2d2", null ]
];