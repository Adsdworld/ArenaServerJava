var searchData=
[
  ['update_0',['update',['../classcom_1_1arena_1_1game_1_1entity_1_1_living_entity.html#a7d521abc5d3e944b5c813231f6b5e362',1,'com::arena::game::entity::LivingEntity']]]
];
