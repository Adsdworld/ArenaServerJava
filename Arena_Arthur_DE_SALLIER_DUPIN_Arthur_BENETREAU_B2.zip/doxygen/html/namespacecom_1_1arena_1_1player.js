var namespacecom_1_1arena_1_1player =
[
    [ "ActionEnum", "enumcom_1_1arena_1_1player_1_1_action_enum.html", "enumcom_1_1arena_1_1player_1_1_action_enum" ],
    [ "ResponseEnum", "enumcom_1_1arena_1_1player_1_1_response_enum.html", "enumcom_1_1arena_1_1player_1_1_response_enum" ],
    [ "Player", "namespacecom_1_1arena_1_1player.html#aade8fec7513360f537d8bb72c9ff0804", null ]
];