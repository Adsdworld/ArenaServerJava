var classcom_1_1arena_1_1game_1_1_game =
[
    [ "Game", "classcom_1_1arena_1_1game_1_1_game.html#ad04a254bc208083ccab35c9d1830b519", null ],
    [ "addEntity", "classcom_1_1arena_1_1game_1_1_game.html#a8a86b7d8d530a34fdaaf1e5267a09c03", null ],
    [ "clearUnityGame", "classcom_1_1arena_1_1game_1_1_game.html#a8c6b3325dbc97791c22713749e6da9fb", null ],
    [ "clearUnityGame", "classcom_1_1arena_1_1game_1_1_game.html#a03caed79873439ea7840bcf84da50049", null ],
    [ "dealDamageToEnnemies", "classcom_1_1arena_1_1game_1_1_game.html#aa934a351d8c7e918b1827acea367f538", null ],
    [ "getEnemies", "classcom_1_1arena_1_1game_1_1_game.html#a0b267497f8102331c55033a490366cb6", null ],
    [ "getLivingEntitiesOfTeam", "classcom_1_1arena_1_1game_1_1_game.html#a99b1ae6266ec1472b17c1c91ab317d48", null ],
    [ "getLivingEntity", "classcom_1_1arena_1_1game_1_1_game.html#a01b70f6e64d357a30380c853ed38aa80", null ],
    [ "getLivingEntityByGeneralId", "classcom_1_1arena_1_1game_1_1_game.html#a0662143cb99151a6103f02654f44bd4d", null ],
    [ "getLivingEntityByGeneralId", "classcom_1_1arena_1_1game_1_1_game.html#a8ce83bd26b76c1b435dfa8181813351c", null ],
    [ "getPlayersOfTeam", "classcom_1_1arena_1_1game_1_1_game.html#ac15eead37bc081fa37e308c7add5050b", null ],
    [ "healSelf", "classcom_1_1arena_1_1game_1_1_game.html#a2dbf66380e70ad2cf1bea880455de2d7", null ],
    [ "livingEntityAlreadyExists", "classcom_1_1arena_1_1game_1_1_game.html#a4d3dc130b0376286b71a8871c939d87c", null ],
    [ "removeEntity", "classcom_1_1arena_1_1game_1_1_game.html#ad9427db25c2ffdfae59c218edef796eb", null ],
    [ "yourEntityIs", "classcom_1_1arena_1_1game_1_1_game.html#a9e562af4dc2042963b0487005ff537bd", null ]
];