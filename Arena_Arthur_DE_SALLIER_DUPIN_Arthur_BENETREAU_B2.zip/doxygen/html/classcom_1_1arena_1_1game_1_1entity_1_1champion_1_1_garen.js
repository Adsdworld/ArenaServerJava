var classcom_1_1arena_1_1game_1_1entity_1_1champion_1_1_garen =
[
    [ "Garen", "classcom_1_1arena_1_1game_1_1entity_1_1champion_1_1_garen.html#a8ddb575a9208522c2af2786b9a99ed75", null ],
    [ "die", "classcom_1_1arena_1_1game_1_1entity_1_1champion_1_1_garen.html#ae8eb10132646824c7e2b6d6e5c3cdf72", null ]
];