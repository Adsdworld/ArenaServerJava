var classcom_1_1arena_1_1game_1_1handler_1_1_cast_q_handler =
[
    [ "handle", "classcom_1_1arena_1_1game_1_1handler_1_1_cast_q_handler.html#aa58e60dd8f39f03e3db782f4d3fbf49b", null ]
];