var classcom_1_1arena_1_1server_1_1_server =
[
    [ "closeGame", "classcom_1_1arena_1_1server_1_1_server.html#a678fd5b0cb83cecfd12fbac13552cfe7", null ],
    [ "createGame", "classcom_1_1arena_1_1server_1_1_server.html#ad5333a07d74ba51a514c7d7544d44d28", null ],
    [ "gameExists", "classcom_1_1arena_1_1server_1_1_server.html#a1b90a5a09ea65e90156cf731a4849dea", null ],
    [ "getGameOfEntity", "classcom_1_1arena_1_1server_1_1_server.html#af9511aac08a1cb9520a06c58e25bf670", null ],
    [ "getGameOfPlayer", "classcom_1_1arena_1_1server_1_1_server.html#a922e39c801ee3fa7d2e6e4cd8fbf5a1b", null ],
    [ "getPlayerByUuid", "classcom_1_1arena_1_1server_1_1_server.html#a77a8bba126c7c1c048fa6ed4bc25d8e9", null ],
    [ "registerPlayer", "classcom_1_1arena_1_1server_1_1_server.html#a6c367073ee22d8e2120b3e8b97aee0cb", null ],
    [ "serverExists", "classcom_1_1arena_1_1server_1_1_server.html#a2b1919b31f969bc6968740ba56c6ef37", null ],
    [ "subscribePlayerToGame", "classcom_1_1arena_1_1server_1_1_server.html#aeadf5627add5c400659d64e47fde6da9", null ]
];