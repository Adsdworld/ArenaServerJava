var interfacecom_1_1arena_1_1game_1_1entity_1_1_i_living_entity_lock =
[
    [ "isCastLocked", "interfacecom_1_1arena_1_1game_1_1entity_1_1_i_living_entity_lock.html#ade166c930d9f58ef848183c486eb9c4d", null ],
    [ "isLocked", "interfacecom_1_1arena_1_1game_1_1entity_1_1_i_living_entity_lock.html#a6038a6d9a2e4a73e07da104d452aed8c", null ],
    [ "isMoveLocked", "interfacecom_1_1arena_1_1game_1_1entity_1_1_i_living_entity_lock.html#a546df2c0977acb7fd9f81d8f7f9fa653", null ],
    [ "isSkinAnimationLocked", "interfacecom_1_1arena_1_1game_1_1entity_1_1_i_living_entity_lock.html#a93ba0e48a928459a2721c4dc184ee602", null ],
    [ "lockEntity", "interfacecom_1_1arena_1_1game_1_1entity_1_1_i_living_entity_lock.html#ad7ada1c47f19511fa36036b1bee514c8", null ],
    [ "lockEntityCast", "interfacecom_1_1arena_1_1game_1_1entity_1_1_i_living_entity_lock.html#abdc6f27ea557534b23d715b24f149b64", null ],
    [ "lockEntityMove", "interfacecom_1_1arena_1_1game_1_1entity_1_1_i_living_entity_lock.html#aaab75a8d8d1bb6fdb14855bdedb173da", null ],
    [ "lockSkinAnimation", "interfacecom_1_1arena_1_1game_1_1entity_1_1_i_living_entity_lock.html#a8c3eb44b721b08a2c89ab56bb3aee4bf", null ]
];